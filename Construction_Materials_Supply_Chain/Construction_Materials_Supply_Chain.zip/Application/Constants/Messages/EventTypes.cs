﻿namespace Application.Constants.Messages
{
    public static class EventTypes
    {
        public const string TransportCreated = "Transport.Created";
    }
}
