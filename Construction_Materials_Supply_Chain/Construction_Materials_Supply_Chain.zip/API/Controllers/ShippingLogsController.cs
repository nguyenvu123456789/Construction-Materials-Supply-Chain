﻿using API.DTOs;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Services.Interfaces;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShippingLogsController : ControllerBase
    {
        private readonly IShippingLogService _service;
        private readonly IMapper _mapper;

        public ShippingLogsController(IShippingLogService service, IMapper mapper)
        {
            _service = service;
            _mapper = mapper;
        }

        [HttpGet]
        public ActionResult<IEnumerable<ShippingLogDto>> GetAllShippingLogs()
        {
            var logs = _service.GetAll();
            return Ok(_mapper.Map<IEnumerable<ShippingLogDto>>(logs));
        }

        [HttpGet("search")]
        public ActionResult<IEnumerable<ShippingLogDto>> Search([FromQuery] string status)
        {
            var logs = _service.SearchByStatus(status);
            return Ok(_mapper.Map<IEnumerable<ShippingLogDto>>(logs));
        }
    }
}
