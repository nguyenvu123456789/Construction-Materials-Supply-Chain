﻿namespace Application.Constants
{
    public static class EventTypes
    {
        public const string TransportCreated = "Transport.Created";
    }
}
