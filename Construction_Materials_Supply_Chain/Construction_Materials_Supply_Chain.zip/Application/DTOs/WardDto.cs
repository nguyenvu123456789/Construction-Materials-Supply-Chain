﻿namespace Application.DTOs
{
    public class WardDto
    {
        public string Name { get; set; } = "";
    }
}
