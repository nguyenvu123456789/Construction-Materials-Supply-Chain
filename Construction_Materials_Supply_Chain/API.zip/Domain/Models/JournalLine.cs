﻿namespace Domain.Models
{
    public class JournalLine
    {
        public int JournalLineId { get; set; }
        public int JournalEntryId { get; set; }
        public JournalEntry JournalEntry { get; set; } = default!;
        public int AccountId { get; set; }
        public GlAccount Account { get; set; } = default!;
        public decimal Debit { get; set; }
        public decimal Credit { get; set; }
        public int? PartnerId { get; set; }
        public int? InvoiceId { get; set; }
        public string? LineMemo { get; set; }
    }
}
