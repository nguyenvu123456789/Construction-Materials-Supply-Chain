﻿namespace Application.Constants.Enums
{
    public enum OrderDetailStatus
    {
        Pending,
        Success,
        Rejected
    }
}
