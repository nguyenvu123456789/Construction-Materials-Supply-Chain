﻿namespace Application.Constants.Enums
{
    public enum OtpPurposeEnum
    {
        SensitiveAction = 1,
        NewDeviceLogin = 2,
        ForgotPassword = 3
    }
}
