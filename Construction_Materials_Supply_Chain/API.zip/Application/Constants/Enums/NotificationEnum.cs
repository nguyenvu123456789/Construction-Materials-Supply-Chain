﻿namespace Application.Constants.Enums
{
    public enum NotificationType
    {
        Conversation = 1,
        Alert = 2,
        CrossPartnerAlert = 3,
        LowStockAlert = 4
    }
}
