﻿using Microsoft.AspNetCore.Http;

namespace Application.DTOs
{
    public class UserDto
    {
        public int UserId { get; set; }
        public string UserName { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public string Status { get; set; } = string.Empty;
        public bool HasAvatar { get; set; }
        public string? AvatarUrl { get; set; }
        public int? PartnerId { get; set; }
        public string? ZaloUserId { get; set; }
        public List<string> Roles { get; set; } = new List<string>();
    }

    public class UserCreateDto
    {
        public string UserName { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string? Phone { get; set; }
        public IFormFile? AvatarFile { get; set; }
        public int? PartnerId { get; set; }
        public string? ZaloUserId { get; set; }
        public List<int> RoleIds { get; set; } = new();
    }

    public class UserUpdateDto
    {
        public string? FullName { get; set; }
        public string? Email { get; set; }
        public string? Phone { get; set; }
        public List<int> RoleIds { get; set; } = new();
        public string? Status { get; set; }
        public IFormFile? AvatarFile { get; set; }
        public int? PartnerId { get; set; }
        public string? ZaloUserId { get; set; }
    }

    public class UserProfileUploadDto
    {
        public IFormFile? AvatarFile { get; set; }
        public string? Phone { get; set; }
        public string? FullName { get; set; }
    }
}
