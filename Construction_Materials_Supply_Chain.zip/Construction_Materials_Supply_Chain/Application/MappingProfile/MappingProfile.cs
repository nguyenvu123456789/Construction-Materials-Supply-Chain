﻿using Application.DTOs;
using Application.DTOs.Partners;
using AutoMapper;
using Domain.Models;

namespace Application.MappingProfile
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<User, UserDto>()
                .ForMember(dest => dest.Roles, opt =>
                    opt.MapFrom(src => src.UserRoles.Select(ur => ur.Role.RoleName).ToList()));
            CreateMap<UserDto, User>()
                .ForMember(dest => dest.UserRoles, opt => opt.Ignore());
            CreateMap<User, AuthResponseDto>();

            CreateMap<ActivityLog, ActivityLogDto>()
                .ForMember(dest => dest.UserName, opt => opt.MapFrom(src => src.User != null ? src.User.UserName : null));
            CreateMap<ActivityLogDto, ActivityLog>()
                .ForMember(dest => dest.User, opt => opt.Ignore());

            CreateMap<Warehouse, WarehouseDto>().ReverseMap();
            CreateMap<Transport, TransportDto>().ReverseMap();
            CreateMap<ShippingLog, ShippingLogDto>().ReverseMap();
            CreateMap<Import, ImportResponseDto>()
                       .ForMember(dest => dest.InvoiceCode, opt => opt.Ignore())
                       .ForMember(dest => dest.CreatedAt, opt => opt.MapFrom(src => src.CreatedAt ?? DateTime.UtcNow));

            CreateMap<ImportRequestDto, Import>().ReverseMap();
            CreateMap<Material, MaterialDto>()
                        .ForMember(dest => dest.CategoryName, opt => opt.MapFrom(src => src.Category.CategoryName))
                        .ForMember(dest => dest.PartnerName, opt => opt.MapFrom(src => src.Partner.PartnerName))
                        .ForMember(dest => dest.Quantity, opt => opt.MapFrom(src => src.Inventories.FirstOrDefault()!.Quantity))
                        .ForMember(dest => dest.WarehouseName, opt => opt.MapFrom(src => src.Inventories.FirstOrDefault()!.Warehouse.WarehouseName))
                        .ReverseMap();
            CreateMap<Import, PendingImportResponseDto>()
            .ForMember(dest => dest.Materials, opt => opt.MapFrom(src => src.ImportDetails));

            CreateMap<ImportDetail, PendingImportMaterialResponseDto>();
            CreateMap<Export, ExportResponseDto>()
                        .ForMember(dest => dest.Details, opt => opt.MapFrom(src => src.ExportDetails));

            CreateMap<ExportDetail, ExportDetailResponseDto>();


            CreateMap<MaterialCheck, MaterialCheckDto>().ReverseMap();
            CreateMap<Role, RoleDto>().ReverseMap();
            CreateMap<Category, CategoryDto>().ReverseMap();


            CreateMap<Partner, PartnerDto>()
                .ForMember(d => d.PartnerTypeName, o => o.MapFrom(s => s.PartnerType.TypeName));
            CreateMap<PartnerCreateDto, Partner>();
            CreateMap<PartnerUpdateDto, Partner>();
            CreateMap<PartnerType, PartnerTypeDto>()
                .ForMember(d => d.Partners, o => o.Ignore());
        }
    }
}