﻿using Application.DTOs;

namespace Application.Services.Interfaces
{
    public interface IRegionService
    {
        IEnumerable<RegionDto> GetAll();
        RegionDto? GetById(int id);
        RegionDto Create(RegionCreateDto dto);
        void Update(int id, RegionUpdateDto dto);
        void Delete(int id);
    }
}
